#ifndef DELAY_H
#define DELAY_H

#include <QTime>
#include <QCoreApplication>
#include <QEventLoop>

void delay(int millisecondsToWait);

#endif // DELAY_H
